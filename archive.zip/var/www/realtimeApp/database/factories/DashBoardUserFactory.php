<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\DashBoardUser;
use Faker\Generator as Faker;

$factory->define(DashBoardUser::class, function (Faker $faker) {
    return [
        //
    ];
});
