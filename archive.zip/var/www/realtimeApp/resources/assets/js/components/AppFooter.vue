<template>
  <v-footer class="pa-3">
    Sample
    <v-spacer></v-spacer>
    <div>&copy; {{ new Date().getFullYear() }} create by ito-san</div>
  </v-footer>
</template>